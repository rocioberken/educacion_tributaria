<?php
	$year = date('Y');
	$month = date('m');
	$day = date('d');
		echo json_encode(array(
		array(
			'id' => 332,
			'title' => "Instituto Santa Ana y San Joaquín ",
			'start' => "2018-04-09",
			'url' => "#"
		),
		array(
			'id' => 333,
			'title' => "Esc. de Com. N°30 DE 18 Dr. Esteban Gascón ",
			'start' => "2018-04-09",
			'url' => "#"
		),
		array(
			'id' => 334,
			'title' => "Instituto River Plate",
			'start' => "2018-04-10",
			'url' => "#"
		),
		array(
			'id' => 335,
			'title' => " Esc. de Com. N°30 DE 18 Dr. Esteban Gascón",
			'start' => "2018-04-12",
			'url' => "#"
		),
		array(
			'id' => 336,
			'title' => "Instituto Industrial Huergo",
			'start' => "2018-04-12",
			'url' => "#"
		),
		array(
			'id' => 339,
			'title' => "Esc. de Com. N° 05 DE 03 José de San Martín",
			'start' => "2018-04-13",
			'url' => "#"
		),
		array(
			'id' => 333,
			'title' => "Instituto Redemptrix Captivorum",
			'start' => "2018-04-16",
			'url' => "#"
		),
		array(
			'id' => 334,
			'title' => "Instituto Privado Complejo Educativo Nuevo Sol",
			'start' => "2018-04-17",
			'url' => "#"
		),
		array(
			'id' => 335,
			'title' => "Instituto Adoratrices",
			'start' => "2018-04-17",
			'url' => "#"
		),
		array(
			'id' => 335,
			'title' => "Instituto San Tarsicio",
			'start' => "2018-04-18",
			'url' => "#"
		),
		array(
			'id' => 336,
			'title' => "Istituto Hogar de Niños Ramón Falcón",
			'start' => "2018-04-18",
			'url' => "#"
		),
		array(
			'id' => 339,
			'title' => "Instituto San Marón",
			'start' => "2018-04-19",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Esc. de Com. N° 05 DE 03 José de San Martín",
			'start' => "2018-04-19",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Instituto Schiller",
			'start' => "2018-04-20",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Instituto Integral de Educación",
			'start' => "2018-04-23",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Colegio Inglés Horacio Watson",
			'start' => "2018-04-24",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Colegio Claret",
			'start' => "2018-05-02",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Colegio Claret",
			'start' => "2018-05-08",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Colegio Claret",
			'start' => "2018-05-09",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Escuela Cristiana Evangélica Argentina",
			'start' => "2018-05-03",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Escuela Cristiana Evangélica Argentina",
			'start' => "2018-05-04",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Esc. de Com. N°30 DE 18 Dr. Esteban Gascón",
			'start' => "2018-05-04",
			'url' => "#"
		),		
		array(
			'id' => 344,
			'title' => "Instituto Profesional San José",
			'start' => "2018-05-07",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Evangélica William Morris",
			'start' => "2018-05-07",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Instituto Naciones Unidas",
			'start' => "2018-05-09",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Argentina",
			'start' => "2018-05-10",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Escuela Argentina",
			'start' => "2018-05-11",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Instituto José Manuel Estrada",
			'start' => "2018-05-11",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Instituto José Manuel Estrada",
			'start' => "2018-05-10",
			'url' => "#"
		),		
		array(
			'id' => 344,
			'title' => "Escuela Belgrano Uno",
			'start' => "2018-05-14",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Esc. de Com. N°30 DE 18 Dr. Esteban Gascón",
			'start' => "2018-05-14",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Colegio Presencia",
			'start' => "2018-05-15",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Cristiana Evangélica Argentina",
			'start' => "2018-05-16",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "ET N° 26 DE 06 Confederación Suiza",
			'start' => "2018-05-16",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Instituto Euskal Echea",
			'start' => "2018-05-17",
			'url' => "#"
		),		
		array(
			'id' => 344,
			'title' => "Esc. de Com. N° 05 DE 03 José de San Martín",
			'start' => "2018-05-18",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Esc. de Com. N° 21 DE 11 Cap. Navío Bouchard",
			'start' => "2018-05-21",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Esc. de Com. N° 11 DE 17 Dr. Peralta",
			'start' => "2018-05-22",
			'url' => "#"
		),		
		array(
			'id' => 344,
			'title' => "Instituto Santa María de Nazareth ",
			'start' => "2018-05-23",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => " Instituto Sudamericano Modelo",
			'start' => "2018-05-30",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Instituto Leonardo Sworn",
			'start' => "2018-05-31",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Instituto San Román",
			'start' => "2018-06-01",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Colegio Champagnat",
			'start' => "2018-06-04",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Colegio San Miguel",
			'start' => "2018-06-04",
			'url' => "#"
		),		
		array(
			'id' => 344,
			'title' => "Escuela Cristiana de la Puerta Abierta",
			'start' => "2018-06-06",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Instituto Sacratísimo Corazón de Jesús",
			'start' => "2018-06-07",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Instituto Fasta Catherina",
			'start' => "2018-07-02",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "ET N° 06 DE 12 Fernando Fader",
			'start' => "2018-07-05",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Esc. de Com. N° 03 DE 07 Hipólito Vieytes",
			'start' => "2018-07-11",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Liceo N° 04 DE 01 Remedios de Escalada de San Martín",
			'start' => "2018-09-19",
			'url' => "#"
		),		
		array(
			'id' => 344,
			'title' => "Instituto San Cristóbal",
			'start' => "2018-08-16",
			'url' => "#"
		),array(
			'id' => 343,
			'title' => " Esc. de Com. N° 34 DE 03 Monseñor Miguel de Andrea",
			'start' => "2018-08-24",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => " Esc. de Com. N° 34 DE 03 Monseñor Miguel de Andrea",
			'start' => "2018-08-27",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => " Esc. de Com. N° 34 DE 03 Monseñor Miguel de Andrea",
			'start' => "2018-08-30",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Liceo N° 04 DE 01 Remedios de Escalada de San Martín",
			'start' => "2018-09-05",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Liceo N° 04 DE 01 Remedios de Escalada de San Martín",
			'start' => "2018-09-07",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Instituto San José",
			'start' => "2018-09-10",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Instituto San José",
			'start' => "2018-09-14",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Instituto Nuestra Señora del Huerto",
			'start' => "2018-09-17",
			'url' => "#"
		),		
		array(
			'id' => 344,
			'title' => "Instituto Federico Guillermo Froebel",
			'start' => "2018-09-24",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Instituto San Cristóbal",
			'start' => "2018-10-03",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Instituto Toratenú",
			'start' => "2018-10-04",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Instituto Nuestra Señora del Buen Consejo",
			'start' => "2018-10-10",
			'url' => "#"
		),		
		array(
			'id' => 344,
			'title' => "Instituto San Mateo",
			'start' => "2018-10-30",
			'url' => "#"
		),
		array(
			'id' => 333,
			'title' => "Esc. de Com. N°30 DE 18 Dr. Esteban Gascón",
			'start' => "2019-04-13",
			'url' => "#"
		),
		array(
			'id' => 333,
			'title' => "INST. HOGAR DE NIÑOS RAMON FALCÓN ",
			'start' => "2019-03-13",
			'url' => "#"
		),
		array(
			'id' => 333,
			'title' => "INST. HOGAR DE NIÑOS RAMON FALCÓN ",
			'start' => "2019-03-14",
			'url' => "#"
		),
		array(
			'id' => 334,
			'title' => "LICEO N° 10 DE 06 RICARDO ROJAS",
			'start' => "2019-03-20",
			'url' => "#"
		),
		array(
			'id' => 335,
			'title' => "INSTITUTO SAN JOSE DE LINIERS",
			'start' => "2019-03-21",
			'url' => "#"
		),
		array(
			'id' => 335,
			'title' => "LICEO N° 10 DE 06 RICARDO ROJAS",
			'start' => "2019-03-21",
			'url' => "#"
		),
		array(
			'id' => 336,
			'title' => "INSTITUTO PRIVADO SIMON BOLIVAR",
			'start' => "2019-03-22",
			'url' => "#"
		),
		array(
			'id' => 339,
			'title' => "ESC. DE COM. N° 21 DE 11 CAP. NAVIO BOUCHARD",
			'start' => "2019-03-22",
			'url' => "#"
		),
		array(
			'id' => 333,
			'title' => "ESC. DE COM. N° 21 DE 11 CAP. NAVIO BOUCHARD",
			'start' => "2019-03-26",
			'url' => "#"
		),
		array(
			'id' => 334,
			'title' => "INSTITUTO ROBERTO ARLT",
			'start' => "2019-03-27",
			'url' => "#"
		),
		array(
			'id' => 335,
			'title' => "ESC. DE COM. N° 21 DE 11 CAP. NAVIO BOUCHARD",
			'start' => "2019-03-29",
			'url' => "#"
		),
		array(
			'id' => 335,
			'title' => "ESC. DE COM. N° 15 DE 15 CECILIA GRIERSON",
			'start' => "2019-04-01",
			'url' => "#"
		),
		array(
			'id' => 336,
			'title' => "LICEO N° 12 DE 08 FRAY MAMERTO ESQUIU",
			'start' => "2019-04-03",
			'url' => "#"
		),
		array(
			'id' => 339,
			'title' => "LICEO N° 12 DE 08 FRAY MAMERTO ESQUIU",
			'start' => "2019-04-04",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "LICEO N° 12 DE 08 FRAY MAMERTO ESQUIU",
			'start' => "2019-04-05",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "ET N° 16 DE 17 ESPAÑA",
			'start' => "2019-04-08",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "ET N° 24 DE 17 DEFENSA DE BS. AS.",
			'start' => "2019-04-09",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "INSTITUTO RIVER PLATE",
			'start' => "2019-04-09",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "ET N° 24 DE 17 DEFENSA DE BS. AS.",
			'start' => "2019-04-10",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "COLEGIO SAN MARTIN DE LOS ANDES ",
			'start' => "2019-04-10",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "SECUNDARIA ARGENTINA SCHOOL ",
			'start' => "2019-04-11",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "ET N° 24 DE 17 DEFENSA DE BS. AS.",
			'start' => "2019-04-11",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "ET N° 24 DE 17 DEFENSA DE BS. AS.",
			'start' => "2019-04-12",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "COLEGIO N° 04 DE 09 NICOLAS AVELLANEDA",
			'start' => "2019-04-16",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "COLEGIO INGLES HORACIO WATSON",
			'start' => "2019-04-17",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "INSTITUTO SANTA RITA",
			'start' => "2019-04-23",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "ESCUELA CRISTIANA EVANGELICA ARGENTINA",
			'start' => "2019-04-24",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO SCHILLER",
			'start' => "2019-04-24",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "ESC. DE COM. N° 15 DE 15 CECILIA GRIERSON",
			'start' => "2019-04-25",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "ESCUELA CRISTIANA EVANGELICA ARGENTINA",
			'start' => "2019-04-26",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "ESC. DE COM. N° 31 DE 09 NACIONES UNIDAS",
			'start' => "2019-04-29",
			'url' => "#"
		),
		array(
			'id' => 345,
			'title' => "ESCUELA CRISTIANA EVANGELICA ARGENTINA",
			'start' => "2019-04-29",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "ESC. DE COM. N° 31 DE 09 NACIONES UNIDAS",
			'start' => "2019-05-02",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO SAN PEDRO",
			'start' => "2019-05-02",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO NUESTRA SEÑORA DE LUJAN DE LOS PATRIOTAS ",
			'start' => "2019-05-06",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "ESCUELA CRISTIANA DE LA PUERTA ABIERTA",
			'start' => "2019-05-06",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO PROFESIONAL SAN JOSE",
			'start' => "2019-05-07",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO SAN PEDRO",
			'start' => "2019-05-08",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "INSTITUTO AMANECER",
			'start' => "2019-12-13",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "COLEGIO DEL SALVADOR",
			'start' => "2019-05-14",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "INSTITUTO AMANECER",
			'start' => "2019-05-13",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "INSTITUTO AMANECER",
			'start' => "2019-05-17",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "ESC. DE COM. N° 23 DE 07 DR. LUIS AGOTE ",
			'start' => "2019-05-20",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO REDEMPTRIX CAPTIVORUM",
			'start' => "2019-05-20",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO REDEMPTRIX CAPTIVORUM",
			'start' => "2019-05-21",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO INMACULADO CORAZON DE MARIA ADORATRICESO",
			'start' => "2019-05-21",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "INSTITUTO SUDAMERICANO MODELO",
			'start' => "2019-05-22",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "ESC. DE COM. N° 09 DE 11 JOSE INGENIEROS",
			'start' => "2019-05-23",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "ESC. DE COM. N° 09 DE 11 JOSE INGENIEROS",
			'start' => "2019-05-27",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "ESC. DE COM. N° 09 DE 11 JOSE INGENIEROS",
			'start' => "2019-05-30",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "INSTITUTO SAN PEDRO",
			'start' => "2019-05-30",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO JOSE MANUEL ESTRADA",
			'start' => "2019-05-31",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO SAN ROMAN",
			'start' => "2019-06-04",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO NTRA. SRA. DEL HUERTO ",
			'start' => "2019-06-05",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO SAN ROMAN",
			'start' => "2019-06-06",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO LA PROVIDENCIA",
			'start' => "2019-06-06",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "COLEGIO CHAMPAGNAT",
			'start' => "2019-06-10",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "INSTITUTO SAN JOSE DE LA PALABRA DE DIOS",
			'start' => "2019-06-10",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO SAN ROMAN",
			'start' => "2019-06-11",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "ENS N° 06 DE 02 VICENTE LOPEZ Y PLANES",
			'start' => "2019-06-11",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "ET N° 33 DE 19 FUNDICION MAESTRANZA DEL PLUMERILLO ",
			'start' => "2019-06-12",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO SAN MIGUEL",
			'start' => "2019-06-13",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO LOS ANGELES",
			'start' => "2019-06-14",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO NUESTRA SEÑORA DEL BUEN CONSEJO",
			'start' => "2019-06-19",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "COLEGIO SAN JOSE",
			'start' => "2019-06-21",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO MADRE DEL BUEN CONSEJO",
			'start' => "2019-06-25",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "INSTITUTO SAN CRISTOBAL",
			'start' => "2019-06-27",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO SAN COSME Y SAN DAMIAN",
			'start' => "2019-07-03",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "ET N° 35 DE 18 ING. LATZINA",
			'start' => "2019-07-05",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "COLEGIO EPISCOPAL DE BUENOS AIRES",
			'start' => "2019-07-10",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "COLEGIO EPISCOPAL DE BUENOS AIRES",
			'start' => "2019-07-11",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "ESCUELA SECUNDARIA INTEGRAL SCHOLEM ALEIJEM",
			'start' => "2019-08-22",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "ESCUELA SECUNDARIA INTEGRAL SCHOLEM ALEIJEM",
			'start' => "2019-08-26",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "ESCUELA SECUNDARIA INTEGRAL SCHOLEM ALEIJEM",
			'start' => "2019-08-28",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO TIERRA SANTA",
			'start' => "2019-08-29",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "INSTITUTO CLARET",
			'start' => "2019-08-27",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "INSTITUTO CLARETE",
			'start' => "2019-09-12",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "INSTITUTO INDUSTRIAL LUIS A. HUERGO",
			'start' => "2019-09-24",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "INSTITUTO FASTA CATHERINA",
			'start' => "2019-09-30",
			'url' => "#"
		),
		
		array(
			'id' => 344,
			'title' => "LICEO N° 01 DE 02 JOSE FIGUEROA ALCORTA",
			'start' => "2019-10-08",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "LICEO N° 01 DE 02 JOSE FIGUEROA ALCORTA",
			'start' => "2019-10-09",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "ESC. DE COM. N° 34 DE 03 MONSEÑOR MIGUEL DE ANDREA",
			'start' => "2019-10-25",
			'url' => "#"
		),
	

));
?>