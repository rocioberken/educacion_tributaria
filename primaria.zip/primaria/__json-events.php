<?php
	$year = date('Y');
	$month = date('m');
	$day = date('d');
		echo json_encode(array(
		array(
			'id' => 332,
			'title' => "Escuela Provincia de Río Negro",
			'start' => "2018-03-14",
			'url' => "#"
		),
		array(
			'id' => 333,
			'title' => "Escuela Virgen Generala",
			'start' => "2018-03-16",
			'url' => "#"
		),
		array(
			'id' => 334,
			'title' => "Escuela Luis Leloir",
			'start' => "2018-03-21",
			'url' => "#"
		),
		array(
			'id' => 335,
			'title' => "Escuela Luis Leloir",
			'start' => "2018-03-22",
			'url' => "#"
		),
		array(
			'id' => 335,
			'title' => "Escuela Santa María de los Buenos Aires",
			'start' => "2018-03-23",
			'url' => "#"
		),
		array(
			'id' => 336,
			'title' => "Escuela República del Ecuador",
			'start' => "2018-04-05",
			'url' => "#"
		),
		array(
			'id' => 339,
			'title' => "Escuela Granaderos de San Martín",
			'start' => "2018-04-11",
			'url' => "#"
		),
		array(
			'id' => 333,
			'title' => "Escuela Granaderos de San Martín",
			'start' => "2018-04-12",
			'url' => "#"
		),
		array(
			'id' => 334,
			'title' => "Escuela Granaderos de San Martín",
			'start' => "2018-04-18",
			'url' => "#"
		),
		array(
			'id' => 335,
			'title' => "Escuela Yapeyú",
			'start' => "2018-04-19",
			'url' => "#"
		),
		array(
			'id' => 335,
			'title' => "Escuela Santa María de los Buenos Aires",
			'start' => "2018-04-20",
			'url' => "#"
		),
		array(
			'id' => 336,
			'title' => "Escuela Francisco Desiderio Herrera",
			'start' => "2018-04-25",
			'url' => "#"
		),
		array(
			'id' => 339,
			'title' => "Escuela Antonio Bucich",
			'start' => "2018-04-26",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Carlos María Biedma",
			'start' => "2018-04-27",
			'url' => "#"
		),
		array(
			'id' => 334,
			'title' => "Escuela Reconquista",
			'start' => "2018-05-03",
			'url' => "#"
		),
		array(
			'id' => 335,
			'title' => "Escuela Vicente López y Planes",
			'start' => "2018-05-04",
			'url' => "#"
		),
		array(
			'id' => 335,
			'title' => "Escuela Juan B. Peña",
			'start' => "2018-05-09",
			'url' => "#"
		),
		array(
			'id' => 336,
			'title' => "Escuela Juan B. Peña",
			'start' => "2018-05-10",
			'url' => "#"
		),
		array(
			'id' => 339,
			'title' => "Escuela Organización de los Estados Americanos",
			'start' => "2018-05-11",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela José Alfredo Ferreira",
			'start' => "2018-05-16",
			'url' => "#"
		),
		array(
			'id' => 334,
			'title' => "Escuela Dr. Roberto Mario Ortiz",
			'start' => "2018-05-17",
			'url' => "#"
		),
		array(
			'id' => 335,
			'title' => "Escuela Dr. Roberto Mario Ortiz",
			'start' => "2018-05-18",
			'url' => "#"
		),
		array(
			'id' => 335,
			'title' => "Escuela José María Gutierrez",
			'start' => "2018-05-23",
			'url' => "#"
		),
		array(
			'id' => 336,
			'title' => "Escuela República Árabe de Egipto",
			'start' => "2018-05-24",
			'url' => "#"
		),
		array(
			'id' => 339,
			'title' => "Instituto Virginio Grego",
			'start' => "2018-05-30",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Leandro N. Alem",
			'start' => "2018-05-31",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Ricardo Levene",
			'start' => "2018-06-01",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Dr. Pedro Goyena",
			'start' => "2018-06-08",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela José Mármol ",
			'start' => "2018-06-11",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Enrique Banch",
			'start' => "2018-06-15",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela José Mármol ",
			'start' => "2018-06-18",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela José Mármol ",
			'start' => "2018-06-19",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Enrique Banch"
			'start' => "2018-06-22",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela República Oriental del Uruguay  ",
			'start' => "2018-08-08",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela República Oriental del Uruguay ",
			'start' => "2018-08-14",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Alte. Manuel Blanco Encalada ",
			'start' => "2018-08-15",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Provincia de La Pampa",
			'start' => "2018-08-22",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Provincia de La Pampa",
			'start' => "2018-08-23",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Gabriela Mistral",
			'start' => "2018-08-24",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela República Oriental del Uruguay ",
			'start' => "2018-08-29",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela República Oriental del Uruguay ",
			'start' => "2018-08-30",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Alvarez Thomas ",
			'start' => "2018-09-04",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Instituto Formar Futuro",
			'start' => "2018-09-03",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Instituto Árabe Argentino y Escuela Prov. de La Pampa",
			'start' => "2018-09-06",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Dr. Antonio Dellepiane",
			'start' => "2018-09-12",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Juan Golfarini",
			'start' => "2018-09-14",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Juan Golfarini",
			'start' => "2018-09-13",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela José Hernández",
			'start' => "2018-09-17",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Familia de Cabezón",
			'start' => "2018-09-18",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Dr. Antonio Dellepiane",
			'start' => "2018-09-19",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Juan Golfarinii",
			'start' => "2018-09-20",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Castelli",
			'start' => "2018-10-03",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Antonio Devoto ",
			'start' => "2018-10-09",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela San Juan Bosco",
			'start' => "2018-10-10",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Antonio Devoto ",
			'start' => "2018-10-12",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela José María Bustillo",
			'start' => "2018-10-18",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Francisco Beiró",
			'start' => "2018-10-23",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Amadeo Jacques",
			'start' => "2018-10-24",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Castelli",
			'start' => "2018-10-25",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Provincia de Córdoba",
			'start' => "2018-10-26",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Gral. Belgrano",
			'start' => "2018-11-15",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela República de Venezuela",
			'start' => "2018-11-16",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Angel Gallardo",
			'start' => "2018-11-20",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Agustín Caffarena",
			'start' => "2018-11-21",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela Agustín Caffarena",
			'start' => "2018-11-23",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela José Ernesto Galloni",
			'start' => "2018-12-11",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Escuela José Ernesto Galloni",
			'start' => "2018-12-12",
			'url' => "#"
		),

/*******************************          2019          *******************************/

		array(
			'id' => 344,
			'title' => "Escuela Aristóbulo del Valle",
			'start' => "2019-03-13",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Aristóbulo del Valle",
			'start' => "2019-03-20",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Provincia de Santa Cruz",
			'start' => "2019-03-22",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Escuela Prof. Felipe Boero",
			'start' => "2019-03-25",
			'url' => "#"
			),
		array(
			'id' => 344,
			'title' => "Escuela Prof. Felipe Boero",
			'start' => "2019-03-26",
			'url' => "#"
			),
		array(
			'id' => 345,
			'title' => "Escuela Prof. Felipe Boero",
			'start' => "2019-04-27",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Aristóbulo del Valle",
			'start' => "2019-04-03",
			'url' => "#"
			),
		array(
			'id' => 344,
			'title' => "Escuela Aristóbulo del Valle",
			'start' => "2019-04-10",
			'url' => "#"
			),
		array(
			'id' => 344,
			'title' => "Escuela Gral. Juan Galo Lavalle",
			'start' => "2019-05-03",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Escuela Santa María de los Buenos Aires ",
			'start' => "2019-05-06",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Virgen Generala ",
			'start' => "2019-05-07",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Republica Arabe de Egipto",
			'start' => "2019-05-09",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Escuela Gral. Juan Galo Lavalle",
			'start' => "2019-05-10",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Pedro Goyena",
			'start' => "2019-05-14",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Instituto Virginio Grego",
			'start' => "2019-05-20",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Antonio Bucich",
			'start' => "2019-05-21",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Escuela Republica del Ecuador",
			'start' => "2019-05-22",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Republica Dominicana",
			'start' => "2019-05-24",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Amadeo Jacques",
			'start' => "2019-05-28",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Escuela José Mármol",
			'start' => "2019-05-30",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Mariscal del Perú",
			'start' => "2019-05-31",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Escuela Reconquista",
			'start' => "2019-06-03",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Reconquista",
			'start' => "2019-06-04",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Escuela Reconquista",
			'start' => "2019-06-03",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Federico Leloir",
			'start' => "2019-06-05",
			'url' => "#"
			),
		array(
			'id' => 344,
			'title' => "Escuela Castelli ",
			'start' => "2019-06-06",
			'url' => "#"
			),
		array(
			'id' => 344,
			'title' => "Escuela República de Venezuela",
			'start' => "2019-06-13",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Escuela República de Venezuela",
			'start' => "2019-06-14",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Mariano Sánchez de Loria",
			'start' => "2019-06-27",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Mariano Sánchez de Loria",
			'start' => "2019-07-04",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Escuela Dr. Juan Balestra",
			'start' => "2019-07-17",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Dr. Juan Balestra",
			'start' => "2019-07-19",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Escuela Provincia de Entre Ríos",
			'start' => "2019-08-21",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Provincia de Entre Ríos",
			'start' => "2019-08-26",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Escuela Rufino Sánchez",
			'start' => "2019-08-29",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Roberto Billinghurt ",
			'start' => "2019-08-30",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Roberto Billinghurt",
			'start' => "2019-09-02",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Escuela Roberto Billinghurt ",
			'start' => "2019-09-24",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela María Sklodowska de Curie",
			'start' => "2019-09-25",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Escuela Roberto Billinghurt ",
			'start' => "2019-09-27",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Carlos Pellegrini ",
			'start' => "2019-10-02",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Escuela Carlos Pellegrini ",
			'start' => "2019-10-03",
			'url' => "#"
		),
		
		array(
			'id' => 343,
			'title' => "Escuela Pedro Inchauspe",
			'start' => "2019-10-08",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Paul Groussac",
			'start' => "2019-10-17",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Escuela Paul Groussac",
			'start' => "2019-10-18",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Francisco Desiderio Herrera",
			'start' => "2019-11-04",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Francisco Desiderio Herrera",
			'start' => "2019-11-05",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Escuela Dr. José Benjamín Zubiaur ",
			'start' => "2019-11-06",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Escuela Dr. José Benjamín Zubiaur ",
			'start' => "2019-11-11",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Olegario Victor Andrade ",
			'start' => "2019-11-15",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Escuela Olegario Victor Andrade ",
			'start' => "2019-11-22",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Escuela Olegario Victor Andrade ",
			'start' => "2019-11-20",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Escuela Paul Groussac",
			'start' => "2019-11-25",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Escuela Dr. José Benjamín Zubiaur ",
			'start' => "2019-11-26",
			'url' => "#"
		),



		
		
		


));
?>