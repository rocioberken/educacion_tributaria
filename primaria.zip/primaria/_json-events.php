<?php
	$year = date('Y');
	$month = date('m');
	$day = date('d');
		echo json_encode(array(
		array(
			'id' => 332,
			'title' => "Visita a la Escuela Primaria Provincia de Río Negro. ",
			'start' => "2018-03-14",
			'url' => "#"
		),
		array(
			'id' => 333,
			'title' => "visita a la Escuela Primaria Virgen Generala.",
			'start' => "2018-03-16",
			'url' => "#"
		),
		array(
			'id' => 334,
			'title' => "Visita a la Escuela Primaria Luis Leloir.",
			'start' => "2018-03-21",
			'url' => "#"
		),
		array(
			'id' => 335,
			'title' => "Visita a la Escuela Primaria Luis Leloir.",
			'start' => "2018-03-22",
			'url' => "#"
		),
		array(
			'id' => 335,
			'title' => "Visita a la Escuela Santa María de los Buenos Aires.",
			'start' => "2018-03-23",
			'url' => "#"
		),
		array(
			'id' => 336,
			'title' => "Visita a la Escuela República del Ecuador.",
			'start' => "2018-04-05",
			'url' => "#"
		),
		array(
			'id' => 339,
			'title' => "Charla taller en la Escuela de Comercio Esteban Agustín Gascón.",
			'start' => "2018-04-09",
			'url' => "#"
		),
		array(
			'id' => 339,
			'title' => "Charla taller en Inst. Santa Ana y San Joaquín.",
			'start' => "2018-04-09",
			'url' => "#"
		),
		array(
			'id' => 339,
			'title' => "Charla taller en la Escuela de Comercio Esteban Agustín Gascón.",
			'start' => "2018-04-10",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Charla taller en Inst. River Plate.",
			'start' => "2018-04-10",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Visita a la Escuela Granaderos de San Martín.",
			'start' => "2018-04-11",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Visita a la Escuela Granaderos de San Martín.",
			'start' => "2018-04-12",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Charla taller en la Escuela de Comercio Esteban Agustín Gascón y en Inst. Industrial Luis Huergo.",
			'start' => "2018-04-12",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Charla taller en Escuela de Comercio José de San Martín.",
			'start' => "2018-04-13",
			'url' => "#"
		),
		array(
			'id' => 341,
			'title' => "Charla taller en Inst. Redemptrix Captivorum y en Colegio Belgrano Uno. ",
			'start' => "2018-04-16",
			'url' => "#"
		),
		array(
			'id' => 342,
			'title' => "Charla taller en Colegio Adoratrices. ",
			'start' => "2018-04-17",
			'url' => "#"
		),
		array(
			'id' => 342,
			'title' => "Charla taller en Complejo Educativo Nuevo Sol. ",
			'start' => "2018-04-17",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Charla taller en Inst. Ramón Falcón y en Colegio San Tarsicio.",
			'start' => "2018-04-18",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Visita a la Escuela Granaderos de San Martín.",
			'start' => "2018-04-18",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Visita a la Escuela Yapeyú.",
			'start' => "2018-04-19",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Charla taller en Colegio San Marón y en la Escuela de Comercio José de San Martín.",
			'start' => "2018-04-19",
			'url' => "#"
		),
		array(
			'id' => 340,
			'title' => "Visita a la Escuela Yapeyú.",
			'start' => "2018-04-19",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Inst. Schiller. ",
			'start' => "2018-04-20",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela Santa María de los Buenos Aires. ",
			'start' => "2018-04-20",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Escuela de Comercio José de San Martín. ",
			'start' => "2018-04-20",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Inst. Integral de Educación.",
			'start' => "2018-04-23",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Colegio Horacio Watson.",
			'start' => "2018-04-24",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Francisco Desiderio Herrera.",
			'start' => "2018-04-25",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Carlos María Biedma.",
			'start' => "2018-04-27",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Colegio Claret.",
			'start' => "2018-05-02",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Colegio Claret.",
			'start' => "2018-05-03",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Reconquista.",
			'start' => "2018-05-03",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Primaria Vicente López y Planes.",
			'start' => "2018-05-04",
			'url' => "#"
			),
		array(
			'id' => 344,
			'title' => "Charla taller en Colegio William Morris.",
			'start' => "2018-05-07",
			'url' => "#"
												),
		array(
			'id' => 345,
			'title' => "charla taller en Inst. Profesional San José.",
			'start' => "2018-05-07",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Colegio Claret y en Colegio Presencia.",
			'start' => "2018-05-08",
			'url' => "#"
			),
		array(
			'id' => 344,
			'title' => "Charla taller en Colegio Claret y en Inst. Naciones Unidas.",
			'start' => "2018-05-09",
			'url' => "#"
			),
		array(
			'id' => 344,
			'title' => "Charla taller en Inst. José Manuel Estrada y en Colegio Argentina School.",
			'start' => "2018-05-10",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Charla taller en Colegio Argentina School.",
			'start' => "2018-05-11",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Colegio Presencia.",
			'start' => "2018-05-15",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Escuela Técnica Confederación Suiza.",
			'start' => "2018-05-16",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Leandro N. Alem.",
			'start' => "2018-05-31",
			'url' => "#"
		),
		
		array(
			'id' => 344,
			'title' => "Charla taller en Instituto Belgrano Day School",
			'start' => "2018-06-22",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Juan B. Peña",
			'start' => "2018-05-09",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Juan B. Peña",
			'start' => "2018-05-10",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Organización de los Estados Americanos",
			'start' => "2018-05-11",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela José Alfredo Ferreira",
			'start' => "2018-05-16",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Dr. Roberto Ortiz",
			'start' => "2018-05-17",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela José María Gutierrez",
			'start' => "2018-05-18",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela José María Gutierrez",
			'start' => "2018-05-22",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela República de Egipto",
			'start' => "2018-05-24",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita al Instituto Virginio Grego",
			'start' => "2018-05-30",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Ricardo Levene",
			'start' => "2018-06-01",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en el Colegio Champagnat y en la Escuela San Miguel",
			'start' => "2018-06-04",
			'url' => "#"
		),
		
		array(
			'id' => 344,
			'title' => "Visita a la Escuela José Mármol",
			'start' => "2018-06-11",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela José Mármol",
			'start' => "2018-06-18",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela José Mármol",
			'start' => "2018-06-19",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla Taller en el Instituto San Román",
			'start' => "2018-06-01",
			'url' => "#"
		),
		array(
						'id' => 344,
			'title' => "Charla Taller en el Instituto Sacratísimo Corazón de Jesús",
			'start' => "2018-06-07",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla Taller en la Escuela Cristiana de la Puerta Abierta",
			'start' => "2018-06-06",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Pedro Goyena",
			'start' => "2018-06-08",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Enrique Banch",
			'start' => "2018-06-15",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Enrique Banch",
			'start' => "2018-06-22",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla Taller en el Instituto Fasta Catherinas",
			'start' => "2018-07-02",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla Taller en la Escuela Técnica Fernando Fader",
			'start' => "2018-07-03",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla Taller en la Escuela Técnica Fernando Fader",
			'start' => "2018-07-05",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla Taller en la Escuela Técnica Fernando Fader",
			'start' => "2018-07-06",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla Taller en  la Escuela de Comercio Hipólito Vieytes",
			'start' => "2018-07-11",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela República Oriental del Uruguay",
			'start' => "2018-08-08",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela República Oriental del Uruguay",
			'start' => "2018-08-14",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Alte. Manuel Blanco Encalada",
			'start' => "2018-08-15",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Instituto San Cristóbal",
			'start' => "2018-08-16",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Provincia de La Pampa",
			'start' => "2018-08-22",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Provincia de La Pampa",
			'start' => "2018-08-23",
			'url' => "#"
			),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Gabriela Mistral y charla taller en la Escuela de Comercio Monseñor Miguel de Andrea",
			'start' => "2018-08-24",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Charla taller en la Escuela de Comercio Monseñor Miguel de Andrea",
			'start' => "2018-08-27",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Visita la Escuela República Oriental del Uruguay",
			'start' => "2018-08-29",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Charla taller en la Escuela de Comercio Monseñor Miguel de Andrea",
			'start' => "2018-08-30",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Antonio Dellepiane",
			'start' => "2018-08-31",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Visita al Instituto Formar Futuro",
			'start' => "2018-09-03",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Álvarez Thomas",
			'start' => "2018-09-04",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Charla taller en el Liceo Escalada de San Martín",
			'start' => "2018-09-05",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Visita al Instituto Árabe Argentino",
			'start' => "2018-09-06",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Charla taller en el Liceo Escalada de San Martín",
			'start' => "2018-09-07",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Antonio Dellepiane y charla taller en el Liceo Escalada de San Martín",
			'start' => "2018-09-12",
			'url' => "#"
				),
	
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Juan Golfarini",
			'start' => "2018-09-14",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Familia de Cabezón",
			'start' => "2018-09-18",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Visita a la  Escuela Antonio Dellepiane",
			'start' => "2018-09-19",
			'url' => "#"
					),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Juan Golfarini",
			'start' => "2018-09-20",
			'url' => "#"
												),
		array(
			'id' => 344,
			'title' => "Charla taller en el Instituto San Cristóbal",
			'start' => "2018-10-03",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Charla taller en Instituto Toratenú",
			'start' => "2018-10-04",
			'url' => "#"
					),
		array(
			'id' => 344,
			'title' => "Final concurso Mi factura, ¡por favor!",
			'start' => "2018-10-08",
			'url' => "#"
					),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Antonio Devoto",
			'start' => "2018-10-09",
			'url' => "#"
						),
		array(
			'id' => 344,
			'title' => "Charla taller Colegio Buen Consejo",
			'start' => "2018-10-10",
			'url' => "#"
						),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Antonio Devoto",
			'start' => "2018-10-12",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela San Juan Bosco",
			'start' => "2018-10-10",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Rafael Ruíz de los Llanos",
			'start' => "2018-10-11",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela José María Bustillo",
			'start' => "2018-10-18",
			'url' => "#"
				),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Castelli",
			'start' => "2018-10-22",
			'url' => "#"
					),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Francisco Beiró",
			'start' => "2018-10-23",
			'url' => "#"
					),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Amadeo Jacques",
			'start' => "2018-10-24",
			'url' => "#"
						),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Castelli",
			'start' => "2018-10-25",
			'url' => "#"
							),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Provincia de Córdoba",
			'start' => "2018-10-26",
			'url' => "#"
								),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela República de Venezuela",
			'start' => "2018-11-02",
			'url' => "#"
									),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Ángel Gallardo",
			'start' => "2018-11-12",
			'url' => "#"
																			),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Gral. Belgrano",
			'start' => "2018-11-15",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela República de Venezuela",
			'start' => "2018-11-16",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Ángel Gallardo",
			'start' => "2018-11-20",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Agustín Caffarena",
			'start' => "2018-11-21",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela José Ernesto Galloni",
			'start' => "2018-12-11",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela José Ernesto Galloni",
			'start' => "2018-12-12",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Primaria Aristóbulo del Valle",
			'start' => "2019-03-13",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Inst. Hogar Ramón Falcón",
			'start' => "2019-03-13",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Inst. Hogar Ramón Falcón",
			'start' => "2019-03-14",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => " Visita a la Escuela Primaria Aristóbulo del Valle",
			'start' => "2019-03-20",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Liceo N°10 Ricardo Rojas",
			'start' => "2019-03-20",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Liceo N°10 Ricardo Rojas",
			'start' => "2019-03-21",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Inst. San José",
			'start' => "2019-03-21",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Primaria Provincia de Santa Cruz",
			'start' => "2019-03-22",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Inst. Privado Simón Bolivar",
			'start' => "2019-03-22",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Escuela de Comercio Nº 21 Capitán de Navío Bouchard",
			'start' => "2019-03-22",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => " Visita a la Escuela Primaria Prof. Felipe Boero",
			'start' => "2019-03-25",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => " Visita a la Escuela Primaria Prof. Felipe Boero",
			'start' => "2019-03-26",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Escuela de Comercio Nº 21 Capitán de Navío Bouchard",
			'start' => "2019-03-26",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Primaria Prof. Felipe Boero",
			'start' => "2019-03-27",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Inst. Roberto Arlt",
			'start' => "2019-03-27",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Escuela de Comercio N° 15 Cecilia Grierson",
			'start' => "2019-04-01",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Primaria Aristóbulo del Valle",
			'start' => "2019-04-03",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Liceo N° 12 Fray Mamerto Esquiú",
			'start' => "2019-04-03",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Escuela de Comercio N° 15 Cecilia Grierson",
			'start' => "2019-04-04",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Liceo N° 12 Fray Mamerto Esquiú",
			'start' => "2019-04-04",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Liceo N° 12 Fray Mamerto Esquiú",
			'start' => "2019-04-05",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => " Charla taller en Escuela Técnica N°16 España",
			'start' => "2019-04-08",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Escuela Técnica N°24 Defensa de Buenos Aires",
			'start' => "2019-04-09",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => " Charla taller en Instituto River Plate",
			'start' => "2019-04-09",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Colegio San Martín de los Andes",
			'start' => "2019-04-10",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Escuela Técnica N°24 Defensa de Buenos Aires",
			'start' => "2019-04-10",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => " Visita a la Escuela Primaria Aristóbulo del Valle",
			'start' => "2019-04-10",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => " Charla taller en Secundaria Argentina School",
			'start' => "2019-04-11",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => " Charla taller en Escuela Técnica N°24 Defensa de Buenos Aires",
			'start' => "2019-04-11",
			'url' => "#"
			),
			array(
			'id' => 344,
			'title' => " Charla taller en Escuela Técnica N°24 Defensa de Buenos Aires",
			'start' => "2019-04-12",
			'url' => "#"
					),
			array(
			'id' => 344,
			'title' => "Charla taller en Escuela de Comercio Nº 21 Capitán de Navío Bouchard",
			'start' => "2019-04-15",
			'url' => "#"
		),
		
			array(
			'id' => 344,
			'title' => " Charla taller en Colegio N°4 Nicolás Avellaneda",
			'start' => "2019-04-16",
			'url' => "#"
		),
		
			array(
			'id' => 344,
			'title' => " Charla taller en Escuela Cristiana de la Puerta Abierta",
			'start' => "2019-04-22",
			'url' => "#"
		),
		
			array(
			'id' => 344,
			'title' => " Charla taller en Inst. Santa Rita",
			'start' => "2019-04-23",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => " Charla taller en Escuela Cristiana Evangélica Argentina",
			'start' => "2019-04-24",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => " Charla taller en Instituto Schiller",
			'start' => "2019-04-24",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => " Charla taller en Escuela Cristiana Evangélica Argentina",
			'start' => "2019-04-26",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => " Charla taller en Escuela Cristiana Evangélica Argentina",
			'start' => "2019-04-29",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => " Charla taller en Escuela de Comercio N°31 Naciones Unidas",
			'start' => "2019-04-29",
			'url' => "#"
		),			
			array(
			'id' => 344,
			'title' => " Visita a la Escuela Primaria Juan Lavalle",
			'start' => "2019-05-10",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => "Charla taller en Escuela de Comercio N° 21 Capitán de Navío Bouchard",
			'start' => "2019-03-29",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => "Charla taller en Instituto San Pedro",
			'start' => "2019-05-02",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => "Charla taller en Comercial 31 DE 9 Naciones Unidas",
			'start' => "2019-05-02",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => "Visita la Escuela Primaria Santa María de los Buenos Aires.",
			'start' => "2019-05-06",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => "Charla taller en Escuela Cristiana de la Puerta Abierta.",
			'start' => "2019-05-06",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => "Charla taller en Instituto Nuestra Señora de Luján de los Patriotas.",
			'start' => "2019-05-06",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => "Visita a la Escuela Primaria Virgen Generala.",
			'start' => "2019-05-07",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => "Charla taller en Instituto San José.",
			'start' => "2019-05-07",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => "Visita a la Escuela Primaria República de Egipto.",
			'start' => "2019-05-09",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => "Charla taller en Instituto San Pedro.",
			'start' => "2019-05-08",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => "Charla taller en Instituto Amanecer.",
			'start' => "2019-05-13",
			'url' => "#"
		),
		
			array(
			'id' => 344,
			'title' => "Visita al Instituto Formar Futuro.",
			'start' => "2019-05-14",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => "Charla taller en Colegio del Salvador.",
			'start' => "2019-05-14",
			'url' => "#"
		),

			array(
			'id' => 344,
			'title' => "Visita a la Escuela Primaria Pedro Goyena.",
			'start' => "2019-05-14",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => "Charla taller en Instituto Amanecer.",
			'start' => "2019-05-17",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => "Visita al Instituto Virginio Grego.",
			'start' => "2019-05-20",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => "Charla taller en Instituto Redemprix Captivorum.",
			'start' => "2019-05-20",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => "Charla taller en Comercial 23 DE 7 Luis Agote.",
			'start' => "2019-05-20",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => "Charla taller en Instituto Redemprix Captivorum.",
			'start' => "2019-05-21",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => "Charla taller en Instituto Inmaculado Corazón de María Adoratrices.",
			'start' => "2019-05-21",
			'url' => "#"
		),
			array(
			'id' => 344,
			'title' => "Visita a la Escuela Primaria Antonio Bucich.",
			'start' => "2019-05-21",
			'url' => "#"
		),array(
			'id' => 344,
			'title' => "Charla taller en Instituto Sudamericano Modelo.",
			'start' => "2019-05-22",
			'url' => "#"
		),array(
			'id' => 344,
			'title' => "Visita a la Escuela Primaria República de Ecuador.",
			'start' => "2019-05-22",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Comercial 9 DE 11 José Ingenieros.",
			'start' => "2019-05-23",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Instituto San Pedro.",
			'start' => "2019-05-23",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Primaria República Dominicana.",
			'start' => "2019-05-24",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Comercial 9 DE 11 José Ingenieros.",
			'start' => "2019-05-27",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Comercial 9 DE 11 José Ingenieros.",
			'start' => "2019-05-30",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en el Instituto José Manuel Estrada.",
			'start' => "2019-05-31",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Primaria Reconquista.",
			'start' => "2019-06-03",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Visita a la Escuela Primaria Reconquista.",
			'start' => "2019-06-04",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "charla taller en Instituto San Román.",
			'start' => "2019-06-04",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "visita a la Escuela Primaria Federico Leloir.",
			'start' => "2019-06-05",
			'url' => "#"
		),array(
			'id' => 344,
			'title' => "Charla taller en Instituto Nuestra Señora del Huerto.",
			'start' => "2019-06-05",
			'url' => "#"
		),array(
			'id' => 344,
			'title' => "Charla taller en Instituto San Román.",
			'start' => "2019-06-05",
			'url' => "#"
		),array(
			'id' => 344,
			'title' => "Charla taller en Instituto San Román.",
			'start' => "2019-06-06",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Colegio La Providencia.",
			'start' => "2019-06-06",
			'url' => "#"
		),
		array(
			'id' => 344,
			'title' => "Charla taller en Colegio Champagnat.",
			'start' => "2019-06-10",
			'url' => "#"
		),
		
		array(
			'id' => 343,
			'title' => "Charla taller en Instituto San Miguel.",
			'start' => "2019-06-13",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Instituto Madre del Buen Consejo.",
			'start' => "2019-06-25",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela primaria Amadeo Jacques.",
			'start' => "2019-05-28",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela primaria José Mármol.",
			'start' => "2019-05-30",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela primaria Mariscal del Perú.",
			'start' => "2019-05-31",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela primaria Castelli.",
			'start' => "2019-06-06",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela Granaderos de San Martín.",
			'start' => "2019-06-10",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela Granaderos de San Martín.",
			'start' => "2019-06-11",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Normal 6 Vicente Lopez y Planes.",
			'start' => "2019-06-11",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Instituto San Román.",
			'start' => "2019-06-11",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en E.T. 33 Fundición Maestranza del Plumerillo.",
			'start' => "2019-06-12",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela primaria República de Venezuela.",
			'start' => "2019-06-13",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela primaria República de Venezuela.",
			'start' => "2019-06-14",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller Instituto Los Ángeles.",
			'start' => "2019-06-14",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Colegio Ntra. Sra. del Buen Consejo.",
			'start' => "2019-06-19",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Colegio San José.",
			'start' => "2019-06-21",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela primaria Mariano Sánchez de Bustamante.",
			'start' => "2019-06-27",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Instituto San Cristóbal.",
			'start' => "2019-06-27",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Instituto San Cosme y San Damián",
			'start' => "2019-07-03",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela Primaria Sánchez de Bustamante",
			'start' => "2019-07-04",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Escuela Técnica N° 35 Ing. Tatzina",
			'start' => "2019-07-05",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Colegio Episcopal",
			'start' => "2019-07-10",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Colegio Episcopal",
			'start' => "2019-07-11",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Comienza la votación concurso “¿Para qué sirven los impuestos?”",
			'start' => "2019-07-15",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => " Visita a la Escuela Primaria Juan Balestra.",
			'start' => "2019-07-17",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela Primaria Juan Balestra",
			'start' => "2019-07-19",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela Primaria Prov. de Entre Ríos",
			'start' => "2019-08-21",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Escuela Scholem Aleijem",
			'start' => "2019-08-22",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Finaliza la votación concurso “¿Para qué sirven los impuestos?”",
			'start' => "2019-08-23",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela Primaria Prov. de Entre Ríos",
			'start' => "2019-08-26",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => " Charla taller en Colegio Claret",
			'start' => "2019-08-27",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Escuela Scholem Aleijem",
			'start' => "2019-08-28",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela Primaria Rufino Sánchez",
			'start' => "2019-08-29",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Inst. Tierra Santa",
			'start' => "2019-08-29",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Escuela Primaria Roberto Billinghurts",
			'start' => "2019-09-02",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Colegio Claret",
			'start' => "2019-09-12",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Evento final concurso “¿Para qué sirven los impuestos?”",
			'start' => "2019-09-16",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela Primaria Roberto Billinghurts",
			'start' => "2019-09-18",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela Primaria Roberto Billinghurts",
			'start' => "2019-09-19",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Escuela de Comercio N°34 Monseñor Miguel de Andrea",
			'start' => "2019-09-20",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Inst. Industrial Luis A. Huergo",
			'start' => "2019-09-24",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela Primaria María de Curie",
			'start' => "2019-09-27",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Liceo 1 José Figueroa Alcorta",
			'start' => "2019-10-07",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Liceo 1 José Figueroa Alcorta",
			'start' => "2019-10-08",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Charla taller en Liceo 1 José Figueroa Alcorta",
			'start' => "2019-10-09",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Evento final del concurso “Mi factura, ¡por favor!”",
			'start' => "2019-10-21",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela Primaria Carlos Morel",
			'start' => "2019-10-25",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela Primaria Carlos Morel",
			'start' => "2019-10-29",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela Primaria Carlos Morel",
			'start' => "2019-11-01",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela Primaria Francisco Desiderio Herrera",
			'start' => "2019-11-04",
			'url' => "#"
		),
		array(
			'id' => 343,
			'title' => "Visita a la Escuela Primaria Francisco Desiderio Herrera",
			'start' => "2019-11-05",
			'url' => "#"
		),


		
		
		


));
?>